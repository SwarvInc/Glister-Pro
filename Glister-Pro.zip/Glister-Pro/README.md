Glister-Pro - Single-Page Bootstrap Template
==============================================

Glister-Pro is a free responsive, single-page HTML5 template base on Twitter Bootstrap framework. 


License
-------
Licensed under http://www.apache.org/licenses/LICENSE-2.0

Features
-----------

A few features that make this template unique
* This Template is compatible in all web browsers, Smartphones and Tablets. 
* HTML is clean and fat-free, you will not find any useless code inside this template.
* Responsive Design.
* Premium Template Quality.


Bug tracker
-----------

Found a bug? Please Inform us at
swarv999@gmail.com



Credits
-------
* Design and development: **Swarv Inc.**
* Photos used in template: **Unsplash** - http://unsplash.com



---------------------------------
FAQ-FREQUENTLY ASKED QUESTIONS
---------------------------------

1. Will these templates work on iPhone, Android platforms, Tabs like kindle and Ipads?

	Yes,  templates work with all Smartphones and Tablets. To, support all the devices we are providing bootstrap Responisve designs WEB Template.

2. What is Web Template?

	WEB template is a responsive design which can be used for desktop users. Users visiting website from desktop browsers can view WEB template


3. Do I need a separate version for Smartphones and Tablets?

	No, WEB Template is compatible in all web browsers, Smartphones and Tablets. 

